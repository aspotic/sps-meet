USE spsmeet
GO
IF OBJECT_ID ('PurgeHistory', 'P') IS NOT NULL
	DROP PROCEDURE PurgeHistory
GO
CREATE PROCEDURE PurgeHistory
AS
DECLARE @i int --counter for while loop
DECLARE @eID int --
DECLARE @eName varchar(255)
DECLARE @numRows int
DECLARE @cuttoffDate datetime
SET @cuttoffDate = DATEADD(DAY,-30,GETDATE())
DECLARE @purgeMeet TABLE (
	idx int Primary Key IDENTITY(1,1)
	, eID int)

INSERT INTO @purgeMeet
SELECT eID FROM meet_history
WHERE dateExpire < @cuttoffDate

SET @i = 1
SET @numRows = (SELECT COUNT(*) FROM @purgeMeet)
IF @numRows > 0
BEGIN
	WHILE (@i <= @numRows)
	BEGIN
		SET @eID = (SELECT eID FROM @purgeMeet WHERE idx = @i)
		SET @eName = (SELECT eName FROM meet_history WHERE eID = @eID)
		
		DELETE FROM meet_history WHERE eID = @eID
		
		IF ( 0 != (SELECT COUNT(*) FROM msg_history WHERE eName = @eName) )
		BEGIN
			DELETE FROM msg_history WHERE eName = @eName
		END

		IF ( 0 != (SELECT COUNT(*) FROM members_history WHERE eName = @eName) )
		BEGIN
			DELETE FROM members_history WHERE eName = @eName
		END

		SET @i = @i + 1
	END
END
GO