USE spsmeet
GO
IF OBJECT_ID ('MoveToHistory', 'P') IS NOT NULL
	DROP PROCEDURE MoveToHistory
GO
CREATE PROCEDURE MoveToHistory AS
DECLARE @i int --counter for while loop
DECLARE @eID int --
DECLARE @eName varchar(255)
DECLARE @numRows int
DECLARE @curDate datetime
DECLARE @oldMeets varchar(8000)
SET @curDate = GETDATE()
DECLARE @oldMeet TABLE (
	idx int Primary Key IDENTITY(1,1)
	, eID int)

INSERT INTO @oldMeet
SELECT eID FROM meet
WHERE dateExpire < @curDate

SET @i = 1
SET @numRows = (SELECT COUNT(*) FROM @oldMeet)
IF @numRows > 0
BEGIN
	WHILE (@i <= @numRows)
	BEGIN
		SET @eID = (SELECT eID FROM @oldMeet WHERE idx = @i)
		SET @eName = (SELECT eName FROM meet WHERE eID = @eID)
		
		INSERT INTO meet_history
		SELECT * FROM meet WHERE eID = @eID
		
		DELETE FROM meet WHERE eID = @eID
		
		IF ( 0 != (SELECT COUNT(*) FROM msg WHERE eName = @eName) )
		BEGIN
			INSERT INTO msg_history
			SELECT * FROM msg WHERE eName = @eName
			
			DELETE FROM msg WHERE eName = @eName
		END

		IF ( 0 != (SELECT COUNT(*) FROM members WHERE eName = @eName) )
		BEGIN
			INSERT INTO members_history
			SELECT * FROM members WHERE eName = @eName
			
			DELETE FROM members WHERE eName = @eName
		END

		SET @i = @i + 1
	END
END
GO
