USE spsmeet
GO
IF OBJECT_ID ('ClientMadeChatRequest', 'P') IS NOT NULL
	DROP PROCEDURE ClientMadeChatRequest
GO
CREATE PROCEDURE ClientMadeChatRequest
	@uDomain varchar(256),
	@uName varchar(256),
	@eName varchar(256)
AS
BEGIN
	DECLARE @numRows int
	DECLARE @curDate datetime
	SET @curDate = GETDATE()
	--get number of records matching domain/name and eID (meeting ID)
	-- in [members]
	SET @numRows = (SELECT count(*) FROM members
		WHERE eName = @eName AND uDomain = @uDomain AND uName = @uName)
	IF (1 = @numRows)
		BEGIN
			--update lastPoll with current datetime
			UPDATE members SET lastPoll = @curDate
			WHERE eName = @eName AND uDomain = @uDomain AND uName = @uName
		END
	ELSE IF (@numRows > 1)
		BEGIN
			--delete all records
			DELETE FROM members
			WHERE eName = @eName AND uDomain = @uDomain AND uName = @uName
			--insert only one record
			INSERT INTO members (uDomain, uName, lastPoll, eName)
			VALUES (@uDomain, @uName, @curDate, @eName)
		END
	ELSE
		BEGIN
			--insert new record
			INSERT INTO members (uDomain, uName, lastPoll, eName)
			VALUES (@uDomain, @uName, @curDate, @eName)
		END
END
GO
