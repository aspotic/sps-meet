CREATE DATABASE spsmeet
GO
USE spsmeet
GO

/*DROP TABLE msg
DROP TABLE msg_history
DROP TABLE meet
DROP TABLE meet_history
DROP TABLE members
DROP TABLE members_history*/

CREATE TABLE msg
(
	mID		int PRIMARY KEY IDENTITY,
	mText	varchar(8000),
	uDomain	varchar(255),
	uName	varchar(255),
	mDate	datetime,
	eName	varchar(250),
	final	int
)

CREATE TABLE msg_history
(
	mID		int PRIMARY KEY,
	mText	varchar(8000),
	uDomain	varchar(255),
	uName	varchar(255),
	mDate	datetime,
	eName	varchar(250),
	final	int
)

CREATE TABLE meet
(
	eID			int PRIMARY KEY IDENTITY,
	eName		varchar(255),
	dateCreate	datetime,
	dateExpire	datetime,
	uDomain		varchar(255),
	uName		varchar(255)
)
CREATE TABLE meet_history
(
	eID			int PRIMARY KEY,
	eName		varchar(255),
	dateCreate	datetime,
	dateExpire	datetime,
	uDomain		varchar(255),
	uName		varchar(255)
)

CREATE TABLE members
(
	uDomain		varchar(255),
	uName		varchar(255),
	lastPoll	datetime,
	eName		varchar(255)
)

CREATE TABLE members_history
(
	uDomain		varchar(255),
	uName		varchar(255),
	lastPoll	datetime,
	eName		varchar(255)
)